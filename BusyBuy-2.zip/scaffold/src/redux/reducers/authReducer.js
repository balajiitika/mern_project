// Implement your code for auth reducer
