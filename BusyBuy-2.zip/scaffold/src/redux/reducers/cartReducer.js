// Implement your code for cart reducer
