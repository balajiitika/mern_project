// Implement your code for product reducer
