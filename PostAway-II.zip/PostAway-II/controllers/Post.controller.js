import Postmodel from "../model/postSchema.js";
import Usermodel from "../model/UserSchema.js";

//get all posts
export const getAllPosts = async (req, res) => {
  try {
    const Posts = await Postmodel.find({});
    if (!Posts) {
      return res.status(404).json({
        message: "No post found"
      })
    }
    res.status(200).json({
      message: "Posts retreived successfully",
      posts: Posts
    })
  } catch (error) {
    console.log("Error in the get all post controller function");

    res.status(500).json({ message: "Internal Server Error" });

  }
}

//new post
export const CreatePost = async (req, res) => {
  try {
    const { caption, imageUrl } = req.body;
    const user = req.user._id

    const NewPost = new Postmodel({ userId: user, caption: caption, imageUrl: imageUrl });

    await NewPost.save();

    res.status(201).json({
      message: "Post created successfully",
      NewPost
    })

  } catch (error) {
    console.log("Error in the create post controller function");
    res.status(500).json({ message: "Internal Server Error", error: error.message });

  }
}

//get single posts
export const GetOnePost = async (req, res) => {
  try {
    const { id } = req.params;

    const Post = await Postmodel.findById(id);
    if (!Post) {
      return res.status(404).json({
        message: `No post found with id${id}`
      })
    }
    res.status(200).json({
      message: "Post fetched successfully",
      Post: Post
    })

  } catch (error) {
    console.log("Error in the get single post controller function");

    res.status(500).json({
      message: "Internal server error",
      error: error.message
    })
  }
}

//update a post (caption Only)
export const UpdatePost = async (req, res) => {
  try {
    const { newCaption } = req.body;
    const { id } = req.params;

    const Post = await Postmodel.findById(id);
    if (!Post) {
      return res.status(404).json({
        message: `No post found with id${id}`
      })
    }

    //we can also user findByIdAndUpdate 
    //But I chose this way
    post.caption = newCaption;
    await post.save()

    res.status(200).json({
      message: "Post updated successfully",
      post: post
    })
  } catch (error) {
    console.log("Error in the update post controller function");

    res.status(500).json({
      message: "Internal server error",
      error: error.message
    })
  }
}

//delete a post
export const deletePost = async (req, res) => {
  try {
    const { id } = req.params;
    const post = await postModel.findByIdAndDelete(id);
    if (!post) {
      return res.status(404).json({
        message: `No post found with id${id}`
      });
    }

    res.status(200).json({
      message: "Post deleted successfully"
    })

  } catch (error) {
    console.log("Error in the delete post controller function");

    res.status(500).json({
      message: "Internal server error",
      error: error.message
    })
  }
}
