import mongoose, { Schema } from "mongoose";

const LikeSchema = new mongoose.Schema({
  userId: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "UserId is required"]
  }],
  postId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Post",
    required: [true, "PostId is required"]
  }
});

const LikeModel = mongoose.model("Like", LikeSchema);
export default LikeModel;