import mongoose from "mongoose";

const commentSchema = new mongoose.Schema({
  UserId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "UserId is required"]
  },
  PostId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Post",
    required: [true, "PostId is required"]
  },
  Content: {
    type: String,
    required: [true, "Some text for the comment is required"],
    minLength: [0, "Minimum 1 character for a comment"]
  }
});

const CommentModel = mongoose.model("Comment", commentSchema);
export default CommentModel;