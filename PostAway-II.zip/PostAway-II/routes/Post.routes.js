import express from "express";
import { createPost, deletePost, getAllPosts, getOnePost, updatePost } from "../controllers/post.controller.js";
import { auth } from "../middleware/auth.js";

const Postrouter = express.Router();

Postrouter.get("/", getAllPosts);
Postrouter.get("/:id", getOnePost);
Postrouter.put("/:id/update", updatePost);
Postrouter.post("/", auth, createPost);
Postrouter.delete("/:id", deletePost);



export default Postrouter;