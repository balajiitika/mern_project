import express from "express";
import { getAllDetails, getUserDetails, login, logout, registerUser, updateUserDetails } from "../controllers/User.controller.js";
import { auth } from "../middleware/auth.js";

const UserRouter = express.Router();

UserRouter.post("/signup", registerUser);
UserRouter.post("/signin", login);
UserRouter.post("/logout", logout);
UserRouter.get("/get-details/:userId", auth, getUserDetails);
UserRouter.get("/get-all-details", auth, getAllDetails)
UserRouter.post("/update-details/:userId", auth, updateUserDetails);
export default UserRouter;