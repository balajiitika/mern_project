import express from "express";
import { connectDatabase } from "./config/connectDB.js";
import cors from "cors";
import UserRouter from "./routes/User.Router.js"
import dotenv from "dotenv";
import PostRouter from "./routes/Post.routes.js";

dotenv.config();

const Server = express();

Server.use(cors());
Server.use(express.json())

Server.use("/v1/api/users", UserRouter);
Server.use("/v1/api/posts", PostRouter);

Server.listen(process.env.PORT, () => {
  console.log("Server is listening on PORT 4100");
  connectDatabase()
})