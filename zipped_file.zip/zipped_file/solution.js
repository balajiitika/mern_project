export const AWS_LINK = 'http://13.233.89.56';
export const PORT = 3000;
